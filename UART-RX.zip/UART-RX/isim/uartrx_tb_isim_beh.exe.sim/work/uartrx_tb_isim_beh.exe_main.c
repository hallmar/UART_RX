/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *STD_STANDARD;
char *IEEE_P_1242562249;
char *IEEE_P_2592010699;
char *WORK_P_2556502258;
char *WORK_P_0450891074;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    ieee_p_1242562249_init();
    work_p_2556502258_init();
    work_p_0450891074_init();
    work_a_1429749438_2675079448_init();
    work_a_2760456609_1990933421_init();
    work_a_4218567821_1145985350_init();
    work_a_1390428595_0632001823_init();
    work_a_1521967808_4057158117_init();
    work_a_4041057810_1865323436_init();
    work_a_1895499690_3090861402_init();
    work_a_2373044771_3766569673_init();
    work_a_1056579100_0432980083_init();
    work_a_3923649624_3429787775_init();
    work_a_1124397286_2372691052_init();


    xsi_register_tops("work_a_1124397286_2372691052");

    STD_STANDARD = xsi_get_engine_memory("std_standard");
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    WORK_P_2556502258 = xsi_get_engine_memory("work_p_2556502258");
    WORK_P_0450891074 = xsi_get_engine_memory("work_p_0450891074");

    return xsi_run_simulation(argc, argv);

}
