/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/mnt/94AA885DAA883E2C/Users/Hallmar Gauti/Desktop/Deutschland/4. Semester/Circuit Design/UART-RX/div6_a.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_2763492388968962707_503743352(char *, char *, unsigned int , unsigned int );
unsigned char ieee_p_2592010699_sub_3488768496604610246_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_374109322130769762_503743352(char *, unsigned char );


static void work_a_1895499690_3090861402_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    int t10;
    int t11;
    int t12;
    int t13;
    char *t14;
    int t15;
    char *t16;
    int t17;
    char *t18;
    unsigned char t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;

LAB0:    xsi_set_current_line(14, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1152U);
    t3 = ieee_p_2592010699_sub_2763492388968962707_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    t1 = (t0 + 4112);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(14, ng0);
    t1 = (t0 + 1968U);
    t5 = *((char **)t1);
    t1 = (t0 + 4208);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 4U);
    xsi_driver_first_trans_fast(t1);
    goto LAB3;

LAB5:    xsi_set_current_line(17, ng0);
    t2 = (t0 + 1672U);
    t5 = *((char **)t2);
    t2 = (t0 + 1968U);
    t6 = *((char **)t2);
    t10 = xsi_mem_cmp(t6, t5, 4U);
    if (t10 == 1)
        goto LAB8;

LAB15:    t2 = (t0 + 2088U);
    t7 = *((char **)t2);
    t11 = xsi_mem_cmp(t7, t5, 4U);
    if (t11 == 1)
        goto LAB9;

LAB16:    t2 = (t0 + 2208U);
    t8 = *((char **)t2);
    t12 = xsi_mem_cmp(t8, t5, 4U);
    if (t12 == 1)
        goto LAB10;

LAB17:    t2 = (t0 + 2328U);
    t9 = *((char **)t2);
    t13 = xsi_mem_cmp(t9, t5, 4U);
    if (t13 == 1)
        goto LAB11;

LAB18:    t2 = (t0 + 2448U);
    t14 = *((char **)t2);
    t15 = xsi_mem_cmp(t14, t5, 4U);
    if (t15 == 1)
        goto LAB12;

LAB19:    t2 = (t0 + 2568U);
    t16 = *((char **)t2);
    t17 = xsi_mem_cmp(t16, t5, 4U);
    if (t17 == 1)
        goto LAB13;

LAB20:
LAB14:    xsi_set_current_line(24, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t1 = (t0 + 4208);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t1);

LAB7:    goto LAB3;

LAB8:    xsi_set_current_line(18, ng0);
    t2 = (t0 + 1032U);
    t18 = *((char **)t2);
    t4 = *((unsigned char *)t18);
    t19 = (t4 == (unsigned char)3);
    if (t19 != 0)
        goto LAB22;

LAB24:
LAB23:    goto LAB7;

LAB9:    xsi_set_current_line(19, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB25;

LAB27:
LAB26:    goto LAB7;

LAB10:    xsi_set_current_line(20, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB28;

LAB30:
LAB29:    goto LAB7;

LAB11:    xsi_set_current_line(21, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB31;

LAB33:
LAB32:    goto LAB7;

LAB12:    xsi_set_current_line(22, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB34;

LAB36:
LAB35:    goto LAB7;

LAB13:    xsi_set_current_line(23, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB37;

LAB39:
LAB38:    goto LAB7;

LAB21:;
LAB22:    xsi_set_current_line(18, ng0);
    t2 = (t0 + 2088U);
    t20 = *((char **)t2);
    t2 = (t0 + 4208);
    t21 = (t2 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t20, 4U);
    xsi_driver_first_trans_fast(t2);
    goto LAB23;

LAB25:    xsi_set_current_line(19, ng0);
    t1 = (t0 + 2208U);
    t5 = *((char **)t1);
    t1 = (t0 + 4208);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 4U);
    xsi_driver_first_trans_fast(t1);
    goto LAB26;

LAB28:    xsi_set_current_line(20, ng0);
    t1 = (t0 + 2328U);
    t5 = *((char **)t1);
    t1 = (t0 + 4208);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 4U);
    xsi_driver_first_trans_fast(t1);
    goto LAB29;

LAB31:    xsi_set_current_line(21, ng0);
    t1 = (t0 + 2448U);
    t5 = *((char **)t1);
    t1 = (t0 + 4208);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 4U);
    xsi_driver_first_trans_fast(t1);
    goto LAB32;

LAB34:    xsi_set_current_line(22, ng0);
    t1 = (t0 + 2568U);
    t5 = *((char **)t1);
    t1 = (t0 + 4208);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 4U);
    xsi_driver_first_trans_fast(t1);
    goto LAB35;

LAB37:    xsi_set_current_line(23, ng0);
    t1 = (t0 + 1968U);
    t5 = *((char **)t1);
    t1 = (t0 + 4208);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 4U);
    xsi_driver_first_trans_fast(t1);
    goto LAB38;

}

static void work_a_1895499690_3090861402_p_1(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    char *t34;
    unsigned char t35;
    unsigned char t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;

LAB0:    xsi_set_current_line(29, ng0);

LAB3:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = (3 - 3);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1672U);
    t9 = *((char **)t8);
    t10 = (2 - 3);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 1672U);
    t17 = *((char **)t16);
    t18 = (1 - 3);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t16 = (t17 + t21);
    t22 = *((unsigned char *)t16);
    t23 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t22);
    t24 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t15, t23);
    t25 = (t0 + 1672U);
    t26 = *((char **)t25);
    t27 = (0 - 3);
    t28 = (t27 * -1);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t25 = (t26 + t30);
    t31 = *((unsigned char *)t25);
    t32 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t24, t31);
    t33 = (t0 + 1032U);
    t34 = *((char **)t33);
    t35 = *((unsigned char *)t34);
    t36 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t32, t35);
    t33 = (t0 + 4272);
    t37 = (t33 + 56U);
    t38 = *((char **)t37);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    *((unsigned char *)t40) = t36;
    xsi_driver_first_trans_fast_port(t33);

LAB2:    t41 = (t0 + 4128);
    *((int *)t41) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_1895499690_3090861402_init()
{
	static char *pe[] = {(void *)work_a_1895499690_3090861402_p_0,(void *)work_a_1895499690_3090861402_p_1};
	xsi_register_didat("work_a_1895499690_3090861402", "isim/uartrx_tb_isim_beh.exe.sim/work/a_1895499690_3090861402.didat");
	xsi_register_executes(pe);
}
